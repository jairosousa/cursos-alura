package capitulo3;

public interface ServicoDeEntrega {
	double para(String cidade);
}