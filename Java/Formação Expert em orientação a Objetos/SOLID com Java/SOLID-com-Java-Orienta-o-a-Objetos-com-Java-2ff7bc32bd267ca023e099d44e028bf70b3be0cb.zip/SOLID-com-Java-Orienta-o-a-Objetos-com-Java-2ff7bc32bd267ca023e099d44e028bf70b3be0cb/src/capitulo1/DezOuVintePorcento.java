package capitulo1;

public class DezOuVintePorcento implements RegraDeCalculo{

	@Override
	public double calcula(Funcionario funcionario) {
		return 0;
	}

}
