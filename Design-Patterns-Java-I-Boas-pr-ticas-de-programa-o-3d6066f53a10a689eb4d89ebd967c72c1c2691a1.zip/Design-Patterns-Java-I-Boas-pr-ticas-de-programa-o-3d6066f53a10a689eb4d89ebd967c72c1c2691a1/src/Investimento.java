interface Investimento {
	double calcula(Conta conta);
}