enum Formato {
	XML, CSV, PORCENTO
}
